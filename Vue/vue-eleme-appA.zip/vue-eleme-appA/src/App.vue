<template>
  <div id="app">
    <v-header :seller='seller'></v-header>

    <!-- 导航 tab-->
  <div class="tab border-1px">
    <div class="tab-item">
      <router-link to="/goods">商品</router-link>
    </div>
     <div class="tab-item">
      <router-link to="/ratings">评论</router-link>
    </div>
     <div class="tab-item">
      <router-link to="/seller">商家</router-link>
    </div>
  </div>
    <router-view></router-view>
  </div>
</template>




<script>
import header from '@/components/header/header.vue'
export default {
  name: 'App',
  data () {
    return {
      seller: {
        // 从api获取
      }
    }
  },
  components: {
    'v-header': header
  },
  created () {
    this.$http.get('https://www.easy-mock.com/mock/5ca2c29464930718b239eb94/lm/vue-eleme-seller')
      .then(res => {
        console.log(res)
        if (res.data.errno === 0) {
          this.seller = Object.assign({}, this.seller, res.data.data)
        }
      })
  }
}
</script>

<style lang="stylus">
@import './common/stylus/mixin.styl'
  // 导航css
.tab
  display flex
  width 100%
  height 40px
  line-height 40px
  border-bottom 1px solid rgba(7, 17, 27, 0.1)
  border-1px(rgba(7, 17, 27, 0.1))
  .tab-item
    flex 1
    text-align center

    & > a
      display block
      font-size 14px
      color rgb(77, 85, 93)
      text-decoration none

      &.router-link-active  
        color rgb(240, 20, 20)   //选中tab
</style>

## Vue
  1.ref 相当于document 放置节点

## 
  npm run build 打包项目 形成dist下的静态资源

  
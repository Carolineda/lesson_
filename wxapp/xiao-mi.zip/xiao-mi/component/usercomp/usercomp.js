// component/usercomp/usercomp.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    img:{
      type:String,
      value:"../../images/订单.png"
      
    },
    order:
    {
      type:String,
      value:'我的订单'
    },
    // setting-img:{
    //   type:String,
    //   // value:"../../images/set.png"
    // },
    // setting-text:
    // {
    //    type:String,
    //   value:'设置'
    // }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
